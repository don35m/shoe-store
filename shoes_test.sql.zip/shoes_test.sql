-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 29, 2015 at 01:24 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=417 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `brands_stores`
--

CREATE TABLE `brands_stores` (
  `id` bigint(20) unsigned NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands_stores`
--

INSERT INTO `brands_stores` (`id`, `brand_id`, `store_id`) VALUES
(1, 52, 190),
(2, 53, 191),
(3, 53, 192),
(4, 64, 201),
(5, 65, 202),
(6, 65, 203),
(8, 77, 213),
(9, 77, 214),
(10, 88, 223),
(11, 89, 224),
(12, 89, 225),
(13, 234, 90),
(14, 235, 91),
(15, 235, 92),
(16, 103, 236),
(18, 104, 238),
(19, 247, 105),
(20, 248, 106),
(21, 248, 107),
(22, 118, 249),
(23, 119, 250),
(24, 119, 251),
(25, 260, 120),
(26, 261, 121),
(27, 261, 122),
(28, 262, 133),
(29, 263, 134),
(30, 264, 134),
(31, 273, 135),
(32, 274, 136),
(33, 274, 137),
(34, 275, 148),
(35, 276, 149),
(36, 277, 149),
(37, 286, 150),
(38, 287, 151),
(39, 287, 152),
(40, 288, 163),
(41, 289, 164),
(42, 290, 164),
(43, 299, 165),
(44, 300, 166),
(45, 300, 167),
(46, 301, 168),
(47, 302, 179),
(48, 303, 180),
(49, 304, 180),
(50, 313, 181),
(51, 314, 182),
(52, 314, 183),
(53, 315, 194),
(54, 316, 195),
(55, 317, 195),
(57, 327, 197),
(58, 328, 198),
(59, 328, 199),
(60, 329, 210),
(61, 330, 211),
(62, 331, 211),
(64, 341, 213),
(65, 342, 214),
(66, 342, 215),
(67, 343, 226),
(68, 344, 227),
(69, 345, 227),
(71, 355, 229),
(72, 356, 230),
(73, 356, 231),
(74, 357, 242),
(75, 358, 243),
(76, 359, 243),
(78, 369, 245),
(79, 370, 246),
(80, 370, 247),
(81, 371, 258),
(82, 372, 259),
(83, 373, 259),
(85, 383, 261),
(86, 384, 262),
(87, 384, 263),
(88, 385, 274),
(89, 386, 275),
(90, 387, 275),
(92, 397, 277),
(93, 398, 278),
(94, 398, 279),
(95, 399, 290),
(96, 400, 291),
(97, 401, 291),
(99, 411, 293),
(100, 412, 294),
(101, 412, 295),
(102, 413, 306),
(103, 414, 307),
(104, 415, 307);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=309 DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brands_stores`
--
ALTER TABLE `brands_stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=417;
--
-- AUTO_INCREMENT for table `brands_stores`
--
ALTER TABLE `brands_stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=106;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=309;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
